<?php

class loginModel extends CI_Model{
    
    public function insert_item()
    {    
        $data = array(
			'emp_username' => $this->input->post('username'),
			'emp_password' => base64_encode($this->input->post('password')),
            'emp_name' => $this->input->post('name'),
            'emp_addr' => $this->input->post('addr'),
			'emp_salary' => $this->input->post('salary')
        );
        return $this->db->insert('emp', $data);
    }
    
    public function find_item()
    {
		$username = $this->input->post('username');
		$pwd = base64_encode($this->input->post('password'));
		$count = $this->db->get_where('emp', array('emp_username' => $username, 'emp_password' => $pwd))->num_rows();
		$data = $this->db->get_where('emp', array('emp_username' => $username, 'emp_password' => $pwd))->row();
		$data->count = $count;
        return $data;
    }
}
?>