<?php

class exerciseCrudModel extends CI_Model{
    public function get_exerciseCrud(){
        $query = $this->db->get("emp");
        return $query->result();
    }
    public function insert_item()
    {    
        $data = array(
            'emp_name' => $this->input->post('name'),
            'emp_addr' => $this->input->post('addr'),
			'emp_salary' => $this->input->post('salary')
        );
        return $this->db->insert('emp', $data);
    }
    public function update_item($id) 
    {
        $data=array(
            'emp_name' => $this->input->post('name'),
            'emp_addr'=> $this->input->post('addr'),
			'emp_salary'=> $this->input->post('salary')
        );
        if($id==0){
            return $this->db->insert('emp',$data);
        }else{
            $this->db->where('emp_id',$id);
            return $this->db->update('emp',$data);
        }        
    }
    public function find_item($id)
    {
        return $this->db->get_where('emp', array('emp_id' => $id))->row();
    }
    public function delete_item($id)
    {
        return $this->db->delete('emp', array('emp_id' => $id));
    }
}
?>