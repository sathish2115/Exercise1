<script type="text/javascript">
$(document).ready(function(){
	$(".loginBtn").submit(function(e){
		e.preventDefault();
		var dataString = $("#loginFrm").serialize();
		$.ajax({
			url: 'login/check',
			type: 'POST',
			data: dataString,
			dataType: 'json',
			success: function(response) {
				alert('esdf');
			},
			error: function(e) {
			//called when there is an error
			//console.log(e.message);
			}
		});
	});
});
</script>



<div class="row">
	<div class="col-md-12">
		<div class="page-header clearfix">
			<h2 class="pull-left">Login</h2>
		</div>
		<form id="loginFrm" action="<?php echo base_url('login/check');?>" method="post">
			<?php
			if ($this->session->flashdata('errors')){
				echo '<div class="alert alert-danger">';
				echo $this->session->flashdata('errors');
				echo "</div>";
			}
			?>
			<div class="form-group">
				<label>Username</label>
				<input type="text" name="username" class="form-control" value="">
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="password" name="password" class="form-control" value="">
			</div>
			<input type="submit" class="btn btn-primary loginBtn" value="Login">
			<a href="<?php echo base_url('register');?>" class="btn btn-primary" value="Register">Register</a>
		</form>
	</div>
</div>