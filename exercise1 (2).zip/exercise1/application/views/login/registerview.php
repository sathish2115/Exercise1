<div class="row">
	<div class="col-md-12">
		<div class="page-header">
			<h2>Create Record</h2>
		</div>
		<p>Please fill this form and submit to add employee record to the database.</p>
		<form action="<?php echo base_url('register/store');?>" method="post">
			<?php
			if ($this->session->flashdata('errors')){
				echo '<div class="alert alert-danger">';
				echo $this->session->flashdata('errors');
				echo "</div>";
			}
			?>
			<div class="form-group">
				<label>Username</label>
				<input type="text" name="username" class="form-control" value="<?php echo set_value('username'); ?>">
			</div>
			<div class="form-group">
				<label>Password</label>
				<input type="password" name="password" class="form-control" value="">
			</div>
			<div class="form-group">
				<label>Confirm Password</label>
				<input type="password" name="cpassword" class="form-control" value="">
			</div>
			<div class="form-group">
				<label>Name</label>
				<input type="text" name="name" class="form-control" value="">
			</div>
			<div class="form-group">
				<label>Address</label>
				<textarea name="addr" class="form-control"></textarea>
			</div>
			<div class="form-group">
				<label>Salary</label>
				<input type="text" name="salary" class="form-control" value="">
			</div>
			<input type="submit" class="btn btn-primary" value="Submit">
			<a href="<?php echo base_url('login');?>" class="btn btn-default">Cancel</a>
		</form>
	</div>
</div>