<div class="row">
	<div class="col-md-12">
		<div class="page-header clearfix">
			<h2 class="pull-left">Employees Details</h2>
			<a href="<?php echo base_url('logout'); ?>" class="btn btn-success pull-right">Logout</a>
		</div>
		<table class='table table-bordered table-striped'>
			<thead>
			  <tr>
				  <th>Name</th>
				  <th>Address</th>
				  <th>Salary</th>
				  <th width="220px">Action</th>
			  </tr>
			</thead>
			<tbody>
				<?php foreach ($data as $item) { ?>      
				<tr>
					<td><?php echo $item->emp_name; ?></td>
					<td><?php echo $item->emp_addr; ?></td>
					<td><?php echo $item->emp_salary; ?></td>          
					<td>
						<form method="DELETE" action="<?php echo base_url('exercisecrud/delete/'.$item->emp_id);?>">
							<a class="btn btn-info" href="<?php echo base_url('exercisecrud/'.$item->emp_id) ?>"><span class='glyphicon glyphicon-eye-open'></span></a>
							<a class="btn btn-primary" href="<?php echo base_url('exercisecrud/edit/'.$item->emp_id) ?>"><span class='glyphicon glyphicon-pencil'></span></a>
							<button type="submit" class="btn btn-danger"><span class='glyphicon glyphicon-trash'></span></button>
						</form>
					</td>
				</tr>
				<?php } ?>
			</tbody>
		</table>
		<a class="btn btn-success pull-right" href="<?php echo base_url('exerciseCrud/create'); ?>"> Create New Item</a>
	</div>
</div>