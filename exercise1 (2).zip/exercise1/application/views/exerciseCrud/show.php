<div class="row">
	<div class="col-md-12">
		<div class="page-header">
			<h1>View Record</h1>
		</div>
		<div class="form-group">
			<label>Name</label>
			<p class="form-control-static"><?php echo $item->emp_name; ?></p>
		</div>
		<div class="form-group">
			<label>Address</label>
			<p class="form-control-static"><?php echo $item->emp_addr; ?></p>
		</div>
		<div class="form-group">
			<label>Salary</label>
			<p class="form-control-static"><?php echo $item->emp_salary	; ?></p>
		</div>
		<p><a href="<?php echo base_url('exerciseCrud');?>" class="btn btn-primary">Back</a></p>
	</div>
</div>