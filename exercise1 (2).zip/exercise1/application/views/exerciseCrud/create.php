<script type="text/javascript">
$(document).ready(function(){
	$(".createBtn").submit(function(e){
		e.preventDefault();
		var dataString = $("#createFrm").serialize();
		$.ajax({
			url: 'exercisecrudCreate',
			type: 'POST',
			data: dataString,
			success: function(data) {
				//called when successful
				// $('#ajaxphp-results').html(data);
			},
			error: function(e) {
			//called when there is an error
			//console.log(e.message);
			}
		});
	});
});
</script>

<div class="row">
	<div class="col-md-12">
		<div class="page-header">
			<h2>Create Record</h2>
		</div>
		<p>Please fill this form and submit to add employee record to the database.</p>
		<form id="createFrm" action="<?php echo base_url('exercisecrudCreate');?>" method="post">
			<?php
			if ($this->session->flashdata('errors')){
				echo '<div class="alert alert-danger">';
				echo $this->session->flashdata('errors');
				echo "</div>";
			}
			?>
			<div class="form-group">
				<label>Name</label>
				<input type="text" name="name" class="form-control" value="">
			</div>
			<div class="form-group">
				<label>Address</label>
				<textarea name="addr" class="form-control"></textarea>
			</div>
			<div class="form-group">
				<label>Salary</label>
				<input type="text" name="salary" class="form-control" value="">
			</div>
			<input type="submit" class="btn btn-primary createBtn" value="Submit">
			<a href="<?php echo base_url('exercisecrud');?>" class="btn btn-default">Cancel</a>
		</form>
	</div>
</div>