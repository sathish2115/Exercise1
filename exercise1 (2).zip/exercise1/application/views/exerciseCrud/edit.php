<div class="row">
    <div class="col-md-12">
        <div class="page-header">
            <h2>Update Record</h2>
        </div>
		<p>Please edit the input values and submit to update the record.</p>
    </div>
</div>

<form action="<?php echo base_url('exercisecrud/update/'.$item->emp_id);?>" method="post">
	<?php
    if ($this->session->flashdata('errors')){
        echo '<div class="alert alert-danger">';
        echo $this->session->flashdata('errors');
        echo "</div>";
    }
    ?>
	<div class="form-group">
		<label>Name</label>
		<input type="text" name="name" class="form-control" value="<?php echo $item->emp_name; ?>">
	</div>
	<div class="form-group">
		<label>Address</label>
		<textarea name="addr" class="form-control"><?php echo $item->emp_addr; ?></textarea>
	</div>
	<div class="form-group">
		<label>Salary</label>
		<input type="text" name="salary" class="form-control" value="<?php echo $item->emp_salary; ?>">
	</div>
	<input type="hidden" name="id" value="<?php echo $item->emp_id; ?>"/>
	<input type="submit" class="btn btn-primary" value="Submit">
	<a href="<?php echo base_url('exercisecrud');?>" class="btn btn-default">Cancel</a>
</form>