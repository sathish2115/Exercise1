<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class login extends CI_Controller {
	public $login;
   
	public function __construct() {
		parent::__construct(); 

		$this->load->library('form_validation');
		$this->load->helper('form');
		$this->load->library('session');
		$this->load->model('loginModel');
		$this->login = new loginModel;
	}

	public function index()
	{
       $this->load->view('login/header');       
       $this->load->view('login/loginview');
       $this->load->view('login/footer');
	}
	
	public function check()
	{
		$this->form_validation->set_rules('username', 'Username', 'trim|required|regex_match[/^[a-zA-Z0-9\s]+$/]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|regex_match[/^[a-zA-Z0-9\s]+$/]');
		
		if ($this->form_validation->run() == FALSE){
            $this->session->set_flashdata('errors', validation_errors());
            redirect(base_url('login'));
        }else{
			$data = $this->login->find_item();
			if($data->count != 0)
			{
				$this->session->set_userdata('username', $data->emp_username);
				if($data->emp_username == "admin") 
					redirect(base_url('exerciseCrud'));
				else 
					redirect(base_url('thankyou'));
			}
			else
			{
				$this->session->set_flashdata('errors', "Username or Password are invalid");
				redirect(base_url('login'));
			}
		}
	}
	
	function logout()
	{
		$this->session->unset_userdata('username');
		redirect(base_url('login'));
	}
	
	public function thankyou()
	{
		$this->load->view('login/header');       
		$this->load->view('login/thankyou');
		$this->load->view('login/footer');
	}
}
?>