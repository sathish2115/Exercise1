<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class exerciseCrud extends CI_Controller {
	public $exerciseCrud;
   
	public function __construct() {
		parent::__construct(); 

		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('exerciseCrudModel');
		$this->exerciseCrud = new exerciseCrudModel;
	}

	public function index()
	{
		$data['data'] = $this->exerciseCrud->get_exerciseCrud();
		$this->load->view('exerciseCrud/header');       
		$this->load->view('exerciseCrud/list',$data);
		$this->load->view('exerciseCrud/footer');
	}
	
	public function show($id)
	{
		$item = $this->exerciseCrud->find_item($id);
		$this->load->view('exerciseCrud/header');
		$this->load->view('exerciseCrud/show',array('item'=>$item));
		$this->load->view('exerciseCrud/footer');
	}

	public function create()
	{
		$this->load->view('exerciseCrud/header');
		$this->load->view('exerciseCrud/create');
		$this->load->view('exerciseCrud/footer');   
	}

	public function store()
	{
		$this->form_validation->set_rules('name', 'Name', 'trim|required|regex_match[/^[a-zA-Z\s]+$/]');
        $this->form_validation->set_rules('addr', 'Address', 'trim|required|regex_match[/^[a-zA-Z0-9\s]+$/]');
		$this->form_validation->set_rules('salary', 'Salary', 'trim|required|regex_match[/^[0-9\s]+$/]');
        if ($this->form_validation->run() == FALSE){
            $this->session->set_flashdata('errors', validation_errors());
            redirect(base_url('exerciseCrud/create'));
        }else{
           $this->exerciseCrud->insert_item();
           redirect(base_url('exerciseCrud'));
        }
	}
	
	public function edit($id)
	{
		$item = $this->exerciseCrud->find_item($id);
		$this->load->view('exerciseCrud/header');
		$this->load->view('exerciseCrud/edit',array('item'=>$item));
		$this->load->view('exerciseCrud/footer');
	}

	public function update($id)
	{
		$this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('addr', 'Address', 'required');
		$this->form_validation->set_rules('salary', 'Salary', 'required');
		if ($this->form_validation->run() == FALSE){
			$this->session->set_flashdata('errors', validation_errors());
			redirect(base_url('exerciseCrud/edit/'.$id));
		}else{ 
			$this->exerciseCrud->update_item($id);
			redirect(base_url('exerciseCrud'));
		}
	}
	
	public function delete($id)
	{
		$item = $this->exerciseCrud->delete_item($id);
		redirect(base_url('exerciseCrud'));
	}
}
?>