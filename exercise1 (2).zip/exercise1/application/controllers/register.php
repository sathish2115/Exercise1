<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class register extends CI_Controller {
	public $register;
   
	public function __construct() {
      parent::__construct(); 

      $this->load->library('form_validation');
      $this->load->library('session');
      $this->load->model('loginModel');
      $this->login = new loginModel;
	}

	public function index()
	{
       $this->load->view('login/header');       
       $this->load->view('login/registerview');
       $this->load->view('login/footer');
	}
	
	public function store()
	{
        $this->form_validation->set_rules('username', 'Username', 'trim|required|is_unique[emp.emp_username]|regex_match[/^[a-zA-Z0-9\s]+$/]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|regex_match[/^[a-zA-Z0-9\s]+$/]');
		$this->form_validation->set_rules('cpassword', 'Confirm Password', 'trim|required|regex_match[/^[a-zA-Z0-9\s]+$/]|matches[password]');
		$this->form_validation->set_rules('name', 'Name', 'trim|required|regex_match[/^[a-zA-Z\s]+$/]');
        $this->form_validation->set_rules('addr', 'Address', 'trim|required|regex_match[/^[a-zA-Z0-9\s]+$/]');
		$this->form_validation->set_rules('salary', 'Salary', 'trim|required|regex_match[/^[0-9\s]+$/]');
        if ($this->form_validation->run() == FALSE){
            $this->session->set_flashdata('errors', validation_errors());
            redirect(base_url('register'));
        }else{
           $this->login->insert_item();
           redirect(base_url('login'));
        }
	}
}
?>